.onLoad <- function(lib, pkg)
{
    print("kinship is loaded")
}
