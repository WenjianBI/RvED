#' original SKAT package
#'
#' original SKAT package function, could be used to compute burden-w, SKAT and SKAT-O results
#' @param Phen a vector of n samples with name of subjects.
#' @param Geno matrix of n*m, where n is sample size and m is SNPs number. rownames(Geno) should be subjects. Missing values should be assigned as NA.
#' @param Cova matrix of n*k, where n is sample size and k is covariates number. rownames(Cova) should be subjects.
#' @param Wt Weight vector of m for m SNPs. Should be the same order as nrow(Geno)
#' @param trait "c" or "b" for "continuous" or "binary".
#' @return a R list with component of p.SKAT, p.Burden and P.SKAT.O for p-values of the three most commonly used methods.
#' @export
SKATs=function(Phen,
               Geno,
               Cova=NULL,
               Wt=NULL,
               trait="c")
{
  if(is.null(Wt)) Wt=Wt.func(Geno)
  if(trait=="c") obj=SKAT_Null_Model(Phen~Cova,out_type = "C",Adjustment = FALSE)
  if(trait=="b") obj=SKAT_Null_Model(Phen~Cova,out_type = "D",Adjustment = FALSE)
  p.SKAT=SKAT(Geno,obj,r.corr=0,weights=sqrt(Wt))$p.value   # the weigting is actually the square root of weights in (Wu, et al).
  p.Burden=SKAT(Geno,obj,r.corr=1,weights=sqrt(Wt))$p.value
  p.SKAT.O=SKAT(Geno,obj,method="SKATO",weights=sqrt(Wt))$p.value
  return(list(p.SKAT=p.SKAT,
              p.Burden=p.Burden,
              p.SKAT.O=p.SKAT.O))
}

#' Burden test with effect directions
#'
#' BT-d test: Burden test with pre-specified effect directions
#' @param Phen a vector of n samples with name of subjects.
#' @param Geno matrix of n*m, where n is sample size and m is SNPs number. rownames(Geno) should be subjects. Missing values should be assigned as NA.
#' @param Cova matrix of n*k, where n is sample size and k is covariates number. rownames(Cova) should be subjects.
#' @param Wt Weight vector of m for m SNPs. Should be the same order as nrow(Geno)
#' @param Nu Direction vector of m for m SNPs. Only 1, -1 or 0(equivalent to the removal of the corresponding SNP) is accepted.
#' @param trait "c" or "b" for "continuous" or "binary".
#' @param one.tail if one tailed test or not
#' @return p-value of the BT-d test
#' @export
Burden.d=function(Phen,
                  Geno,
                  Cova=NULL,
                  Wt=NULL,
                  Nu=NULL,
                  trait="c",
                  one.tail=T)
{
  if(is.null(Wt)) Wt=Wt.func(Geno)
  if(is.null(Nu))
  {
    warning("There is no assignment of Nu, we still use tradtional burden test")
    Nu=rep(1,length(Wt));
    one.tail=F
  }
  Geno.b=apply(t(Geno)*Wt*Nu,2,sum)    # collapse multiple rare variants into one single variable
  if(trait=="c") res=glm(Phen~Geno.b+Cova)
  if(trait=="b") res=glm(Phen~Geno.b+Cova,family = binomial)
  pval=summary(res)$coefficients[2,4]
  if(one.tail)
  {
    coef=summary(res)$coefficients[2,1]
    pval=ifelse(coef>0,pval/2,1-pval/2)
  }
  return(pval)
}


#' SKAT test with effect directions
#'
#' SKAT-d test: SKAT method with pre-specified effect directions
#' @param Phen a vector of n samples with name of subjects.
#' @param Geno matrix of n*m, where n is sample size and m is SNPs number. rownames(Geno) should be subjects. Missing values should be assigned as NA.
#' @param Cova matrix of n*k, where n is sample size and k is covariates number. rownames(Cova) should be subjects.
#' @param Wt Weight vector of m for m SNPs. Should be the same order as nrow(Geno)
#' @param Nu Direction vector of m for m SNPs. Only 1, -1 or 0(equivalent to the removal of the corresponding SNP) is accepted.
#' @param trait "c" or "b" for "continuous" or "binary". "fam.c" for family-based "continuous" trait
#' @param kin if trait = "fam.c", one of kin, ped and ibd should be specified. kin is output of makekinship or bdsmatrix.ibd.
#' @param ped a dataframe with four columns named with c("famid","id","father.id","mother.id"). Used as input of makekinship.
#' @param ibd a dataframe with three columns named with c("id1","id2","x"). Used as input of bdsmatrix.ibd. Should contain
#' @param one.tail if one tailed test or not
#' @return a list with components of 1) p-value of SKAT-d; 2) p-value of SKAT; 3) statistics of SKAT-d; 4) statistics of SKAT
#' @export
SKAT.d=function(Phen,
                Geno,
                Cova=NULL,
                Wt=NULL,
                Nu=NULL,
                trait="c",
                kin=NULL,
                ped=NULL,
                ibd=NULL,
                acc=1e-7,
                lim=1e5)
{
  if(is.null(Wt)) Wt=Wt.func(Geno)
  if(is.null(Nu))
  {
    warning("There is no assignment of Nu, we use default setting of Wt.")
    Nu=Wt
  }
  check.res=Input.check(Phen,Geno,Cova,Wt,Nu,trait,kin,ped,ibd)
  Phen=check.res$Phen
  Geno=check.res$Geno
  X=check.res$X   # updated covariate matriax
  Wt=check.res$Wt
  Nu=check.res$Nu
  kin=check.res$kin

  mu=Nu*1/Wt  # W=diag(Wt); mu=solve(W)%*%Nu
  res=obs.func(Phen,X,trait,Geno,Wt,mu,kin)
  Stats=res$Stats     # observable statistics
  Stats.SKAT=res$Stats.SKAT
  Sigma=res$Sigma     # covariance matrix of t(G)
  mu1=mu*sqrt(Wt)     # sqrt(W)%*%mu

  null.pars=null.para(Sigma,mu1)
  lambda=null.pars$lambda          # parameter "lambda" for weighted sum of chi-square variables (null hypothesis)
  delta=null.pars$delta            # parameter "delta" for weighted sum of chi-square variables (null hypothesis)

  # Statistics and p-values
  pvalue=davies(Stats,lambda,delta=delta,acc=acc,lim=lim)$Qq # /davies(sum(Wt),eig,sigma=sigma)$Qq
  pvalue.SKAT=davies(Stats.SKAT,lambda,acc=acc,lim=lim)$Qq # /davies(sum(Wt),eig,sigma=sigma)$Qq
  return(list(pvalue=pvalue,
              pvalue.SKAT=pvalue.SKAT,
              Stats=Stats,
              Stats.SKAT=Stats.SKAT))
}

